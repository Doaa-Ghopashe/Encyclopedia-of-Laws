﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Encyclopedia_Of_Laws.ViewModels
{
    public class RoleViewModel
    {

        public string RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
